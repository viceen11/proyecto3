@include('layout.master')
<br>
<div class="row align-items-center justify-content-center">
    <div class="col-6">
        <div class="card text-bg-secondary">
            <div class="card-header text-center">
                Ingresar Propuesta
                <hr>
                <div class="card-body">
                    <form method="POST" action="{{route('estudiantes.store')}}">
                        @csrf
                        
                            
                        <select class="form-select" aria-label="Default select example">
                            @foreach($estudiantes as $estudiante)
                            <option selected>{{$estudiante->nombre}}</option>
                            @endforeach
                        </select>
                        <div class="mb-3">
                            <label for="fecha" class="form-label">Fecha entrega de Propuesta</label>
                            <label for="fecha" class="form-control">{{$estudiante->created_at}}</label>
                        </div>
                        
                        <div class="mb-3">
                            <label for="propuesta" class="form-label">Ingrese Propuesta</label>
                            <textarea name="propuesta" class="form-control" id="propuesta" rows="3"></textarea>
                          </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-outline-light " type="submit">Enviar Propuesta</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>






<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="row align-items-center justify-content-center">
    <div class="col-6">
        <div class="card text-bg-secondary">
            <div class="card-header text-center">
                Ingresar Propuesta
                <hr>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('estudiantes.store')); ?>">
                        <?php echo csrf_field(); ?>
                        
                            
                        <select class="form-select" aria-label="Default select example">
                            <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option selected><?php echo e($estudiante->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="mb-3">
                            <label for="fecha" class="form-label">Fecha entrega de Propuesta</label>
                            <label for="fecha" class="form-control"><?php echo e($estudiante->created_at); ?></label>
                        </div>
                        
                        <div class="mb-3">
                            <label for="propuesta" class="form-label">Ingrese Propuesta</label>
                            <textarea name="propuesta" class="form-control" id="propuesta" rows="3"></textarea>
                          </div>
                        <div class="row">
                            <div class="col">
                                <button class="btn btn-outline-light " type="submit">Enviar Propuesta</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</div>





<?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/home/index.blade.php ENDPATH**/ ?>